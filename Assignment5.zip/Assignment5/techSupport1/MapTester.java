import java.util.HashMap;
/**
 * Class for making maps
 *
 * @author Doug Heinbokel
 * @version (1.0)
 */
public class MapTester
{
    // instance variables - replace the example below with your own
    private HashMap<String, String> contacts;

    /**
     * Constructor for objects of class MapTester
     */
    public MapTester()
    {
        // initialise instance variables
        contacts = new HashMap<>();
        contacts.put("Doug Heinbokel", "231-373-2045");
        contacts.put("Bob Heinbokel", "111-222-3333");
    }
    
    /**
     * Print all keys and values associated with them in the contacts map.
     */
    public void printAllKeys()
    {
        System.out.println(contacts.toString());
    }
    
    /**
     * Looks up a number from the contacts map.
     */
    public String lookUpNumber(String name)
    {
        return contacts.get(name);
    }
    
    /**
     * Adds numbers to the HashMap.
     */
    public void enterNumber(String name, String phone)
    {
        // put your code here
        contacts.put(name, phone);
    }
}
