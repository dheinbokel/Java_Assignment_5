import java.util.Random;
import java.util.ArrayList;
/**
 * Prints out one or many random numbers.
 *
 * @author Doug Heinbokel
 * @version (1.0)
 */
public class RandomTester
{
    // instance variables - replace the example below with your own
    private Random newRand;
    private ArrayList<String> response;
    /**
     * Constructor for objects of class RandomTester
     */
    public RandomTester()
    {
        // initialise instance variables
        response = new ArrayList<>();
        response.add("yes");
        response.add("no");
        response.add("maybe");
        response.add("who knows?");
        response.add("shut up");
        newRand = new Random();
    }

    /**
     * Prints one random integer.
     */
    public void printOneRandom()
    {
        // put your code here
        int number = newRand.nextInt();
        System.out.println(number);
    }
    
    /**
     * Generates random number from 1 to max.
     */
    public int getRandom(int min, int max)
    {
        int number = getBetterRandom(min, max);
        return number;
    }
    
    /**
     * Generates random number from min to max.
     * @param int min for minimum number, int max for the maximum value.
     * @return number
     */
    public int getBetterRandom(int min, int max)
    {
        int number = newRand.nextInt(max - min) + min;
        return number;
    }
    
    /**
     * Get back a random responce from response arraylist.
     */
    public String getResponse()
    {
        int number = newRand.nextInt(response.size());
        
        return response.get(number);
    }
    
    /**
     * Rolls a six sided dice and returns the value.
     */
    public int throwDie()
    {
        int number = newRand.nextInt(6)+1;
        return number;
    }
    
    /**
     * Prints as many random integers as the user wants.
     */
    public void printMultiRandom(int amount)
    {
        int numberRandoms = 0;
        while(numberRandoms < amount){
            int number = newRand.nextInt();
            System.out.println(number);
            numberRandoms++;
        }
    }
}
