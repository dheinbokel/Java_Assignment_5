import java.util.Arrays;
/**
 * Sorts an array
 *
 * @author Doug Heinbokel
 * @version 1.0
 */
public class SortingTest
{
    // instance variables - replace the example below with your own
    private int[] numArray;

    /**
     * Constructor for objects of class SortingTest
     */
    public SortingTest()
    {
        // initialise instance variables
        numArray = new int[]{5,3,4,2,1,6};
        printArray(numArray);
    }

    /**
     * Sort the array and then output it to the terminal.
     */
    public void printArray(int[] numbArray)
    {
        // put your code here
        Arrays.sort(numbArray);
        for(int element : numbArray){
            System.out.println(element);
        }
    }
}
