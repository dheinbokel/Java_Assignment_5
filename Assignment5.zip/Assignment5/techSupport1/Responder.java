import java.util.Random;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ArrayList;
/**
 * The responder class represents a response generator object.
 * It is used to generate an automatic response to an input string.
 * 
 * @author     Michael Kölling and David J. Barnes
 * @version    0.1 (2016.02.29)
 */
public class Responder
{
    private Random newRand;
    private HashMap<String, String> response;
    private ArrayList<String> randResponse;
    /**
     * Construct a Responder - nothing to do
     */
    public Responder()
    {
        newRand = new Random();
        response = new HashMap<>();
        randResponse = new ArrayList<>();
        fillResponses();
        fillRandResponse();
    }

    /**
     * Fill the randResponse ArrayList.
     * @param none
     * @return none
     */
    public void fillRandResponse()
    {
        randResponse.add("Keep talking, I'm interested");
        randResponse.add("Impossible!");
        randResponse.add("Couldn't find anything at stack-overflow.");
    }
    
    /**
     * Fill the response HashMap with responses.
     * @param none
     * @return none
     */
    public void fillResponses()
    {
        response.put("slow", "Maybe your hardware ain't so good.");
        response.put("bug", "Could you provide more detail?");
        response.put("expensive", "Eww, poor person.");
        response.put("zygote", "Uh... Can you repeat?");
        response.put("love", "Interesting, can you elaborate?");
        response.put("start", "That is in the manual, look it up.");
        response.put("fire", "Sounds busted my dude.  Bye a new one.");
        response.put("chocolate", "Some would say that's a good thing.");
        response.put("math", "Sorry, what? I wasn't listening.");
        response.put("hate", "CALM DOWN! PLEASE SLOW DOWN!");
    }
    
    /**
     * Picks a random response.
     * @return randResponse value
     */
    public String pickDefault()
    {
        int num = newRand.nextInt(randResponse.size());
        return randResponse.get(num);
    }
    
    /**
     * New version of generateResponse, uses the parameter word to search 
     * keys in the response HashMap.
     * @return generateResponse or the return value of pickDefault().
     */
    public String generateResponse(HashSet<String> words)
    {
        for(String word : words){
            String generateResponse = response.get(word);
            if(generateResponse != null){
                return generateResponse;
            }
        }
        return pickDefault();
    }
    
    /**
     * Generate a response.
     * @return   A string that should be displayed as the response
     */
    /*public String generateResponse(HashSet<String> word)
    {
        
        String generateResponse = response.get(word);
        if(generateResponse != null){
            return generateResponse;
        }
        else{
            return pickDefault();
        }
    }*/
}
