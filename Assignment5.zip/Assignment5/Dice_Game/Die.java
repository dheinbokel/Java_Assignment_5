import java.util.HashMap;
import java.util.Random;
/**
 * Basic methods and fields for the die class.  Will have a HashMap and
 * methods for rolling the die.
 *
 * @author Doug Heinbokel
 * @version 1.0
 */
public class Die
{
    // instance variables - replace the example below with your own
    private HashMap<Integer, Integer> diceMap;
    private Random newRand;
    /**
     * Constructor for objects of class Die
     */
    public Die()
    {
        // initialise instance variables
        diceMap = new HashMap<>();
        newRand = new Random();
        diceMap.put(4,4);
        diceMap.put(6,6);
        diceMap.put(8,8);
        diceMap.put(10,10);
        diceMap.put(12,12);
        diceMap.put(20,20);
        diceMap.put(100,100);
    }

    /**
     * Return value in HashMap
     */
    public int getValue(int diceMax)
    {
        int value = diceMap.get(diceMax);
        
        return value;
    }
    
    /**
     * Return boolean value if key exists.
     */
    public boolean doesExist(int diceMax)
    {
        if(diceMap.containsKey(diceMax)){
            return true;
        }
        else{
            return false;
        }
        
    }
    
    /**
     * Rolls the chosen die and returns the value of the random roll.
     * @param dieMax, int
     * @returns rollValue
     */
    public int rollDie(int dieMax)
    {
        int rollValue = 0;
        rollValue = newRand.nextInt(dieMax)+1;
        
        return rollValue;
    }
}
