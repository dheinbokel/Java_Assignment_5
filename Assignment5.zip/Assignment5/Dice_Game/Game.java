import java.util.HashMap;
/**
 * Interface for playing the dice game.
 *
 * @author Doug Heinbokel
 * @version 1.0
 */
public class Game
{
    // instance variables - replace the example below with your own
    private static final int MAX_DIE = 10;
    private static final int MIN_TARGET = 5;
    private static final int MAX_TARGET = 30;
    private Die dice;
    /**
     * Constructor for objects of class Game
     */
    public Game()
    {
        // initialise instance variables
        dice = new Die();
    }

    /**
     * Play the game.
     * Die types include: 4,6,8,10,12,20,100.
     * Target must be between 5 and 30.
     * Maximum amount of dice is 10.
     * @param String type, int numDice, int target
     * @return none
     */
    public void play(int type, int targetAmount, int diceAmount)
    {
        // put your code here
        if(diceAmount > MAX_DIE || targetAmount < MIN_TARGET || targetAmount > MAX_TARGET || dice.doesExist(type) == false){
            System.out.println("Sorry, read the comments about valid inputs.");
        }
        else{
            int dieMaxValue = dice.getValue(type);
            int numRolls = 0;
            int totalValue = 0;
            int rollValue = 0;
            int oneCounter = 0;
            while(numRolls < diceAmount){
              rollValue = dice.rollDie(dieMaxValue);
              totalValue += rollValue;
              numRolls++;
              System.out.println("You rolled: " + rollValue);
              if(rollValue == 1){
                  oneCounter++;
                }
              while(rollValue == dieMaxValue){
                rollValue = dice.rollDie(dieMaxValue);
                totalValue += rollValue;
                System.out.println("Plus: " + rollValue);
              }
              if(oneCounter == ((int) Math.ceil((diceAmount/2.0)))){
                  totalValue = 0;
                  System.out.println("Oh no! Too many ones were rolled, that's a bust.");
                  break;
                }
            }
            if(totalValue < targetAmount){
                System.out.println("Ouch, didn't quite make it...");
                System.out.println("You rolled: " + totalValue + " and the goal was: " + targetAmount);
            }
            else if(totalValue > targetAmount){
                System.out.println("You zoomed past it...");
                System.out.println("You rolled: " + totalValue + " and the goal was: " + targetAmount);
            }
            else{
                System.out.println("WOOOOO! You nailed it!  You WIN!");
            }
        }
    }
}
